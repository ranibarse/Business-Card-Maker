<?php
session_start();
?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Business Card Maker</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/shop-homepage.css" rel="stylesheet">

</head>

<body style="    background-color: black;">
 <?php include "Includes/header.php"; ?>
 

      <div class="col-lg-9">

        <div class="row">

          <div class="col-lg-12">
            <div class="card h-100">
             
              <div class="card-body">
                <center><h4 class="card-title">
                About us
                </h4></center><hr>
              <div class="row" style="width:100%;">
    <div class="col-md-4" >
   <img src="images/WhatsApp%20Image%202021-05-09%20at%2011.22.47%20AM%20(1).jpeg" style="width:100%; height:300px;"><br> <center><b>Krutika Vinchurkar</b></center>
    </div>
    <div class="col-md-4">
       <img src="images/WhatsApp%20Image%202021-05-09%20at%2011.23.16%20AM%20(1).jpeg" style="width:100%; height:300px;"><br> <center><b>Rani Barse</b></center>
    </div>
     <div class="col-md-4">
     <img src="images/WhatsApp%20Image%202021-05-09%20at%2011.32.06%20AM%20(1).jpeg" style="width:100%; height:300px;"><br><center><b>Pranali Ingole</b></center>
    </div>
  </div>
  <br />  <br />  <br />  <br />  <br />  <br /><br />  <br /><br />  <br /><br />  <br />


              </div>
             
            </div>
          </div>

         

        </div>
        <!-- /.row -->

      </div>
      <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

  </div>
  <!-- /.container -->

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Business Card Maker</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>

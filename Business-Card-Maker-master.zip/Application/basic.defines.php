<?php
			
	define( 'DB_USER', 'root' );
	define( 'DB_PASS', '' );
	define( 'DB_DSN', 'mysql:host=localhost;dbname=business_card_maker;charset=utf8' );
	define( 'BASE_URL', 'http://localhost/inwriting/' );
	define( 'IMG_URL', BASE_URL . 'admin/Product/' );

	define( 'FULL_DATE_FORMAT', 'Y-m-d H:i:s' );
	define( 'DEFAULT_TIME_ZONE', 'Asia/Kolkata' );

	define( 'IMAGE_PATH_THUMB', './Media/Products/Images/Thumb/' );
	define( 'IMAGE_PATH_FULL', './Media/Products/Images/Full/' );

	define( 'RANDOM_GENERATE_STRING', 'abcdefghi^&^&^0123456789' );
	define( 'MIME_TYPE_JPEG', 'image/jpeg' );
	define( 'MIME_TYPE_GIF', 'image/gif' );
	define( 'MIME_TYPE_PNG', 'image/png' );

	define( 'PAGE_TITLE', 'BadaaBazar.com' );

	define( 'ERR_MSG_1', 'Please login first.' );
	define( 'ERR_MSG_2', 'Username or Password not matched.' );
	define( 'ERR_MSG_3', 'Logout successfully.' );
	define( 'ERR_MSG_4', 'User Registered successfully.' );
?>